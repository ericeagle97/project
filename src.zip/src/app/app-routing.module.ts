import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ProductsComponent } from './products/products.component';
import { SignupComponent } from './signup/signup.component';


const routes: Routes = [
  
  {path : "" , component : HomepageComponent},
  {path : "homepage" , component : HomepageComponent},
  {path : "products" , component: ProductsComponent},
  {path : "signup" ,  component : SignupComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
